// server.js — StockRadar backend
// Fetches real (unofficial, free, no API key) data from Yahoo Finance's
// public chart/quoteSummary endpoints, computes cyclic patterns, CFO ratios,
// 52-week-low proximity, and a penny-stock momentum screen — all from
// genuinely fetched historical price data, not hardcoded numbers.
//
// IMPORTANT: this Yahoo endpoint is unofficial and undocumented. It is free
// and needs no signup, which is why it's used here, but it is not a
// guaranteed/supported API. Do not treat this as production-grade
// infrastructure for a funded product — see README.md.

require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3002;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY || null;

if (!ANTHROPIC_API_KEY) {
  console.warn('ANTHROPIC_API_KEY not set in .env — the FUT tab will run its price/momentum screen but skip AI research (balance sheet, shareholding, order book). Add a key to enable it.');
}

app.use(express.static(path.join(__dirname, 'public')));

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

// ---------- Yahoo cookie + crumb handshake ----------
// Yahoo's quoteSummary endpoint (used for market cap / CFO) increasingly
// requires a session cookie plus a "crumb" token, or it returns an error
// page instead of JSON. The chart endpoint (used for price history) has
// generally not required this, which is why fetchChart() below doesn't use it.
let session = { cookie: null, crumb: null, ts: 0 };
const SESSION_TTL_MS = 30 * 60 * 1000;

function parseSetCookie(res) {
  if (typeof res.headers.getSetCookie === 'function') {
    const all = res.headers.getSetCookie();
    if (all && all.length) return all.map(c => c.split(';')[0]).join('; ');
  }
  const single = res.headers.get('set-cookie');
  return single ? single.split(';')[0] : null;
}

async function getSession() {
  if (session.crumb && Date.now() - session.ts < SESSION_TTL_MS) return session;
  const warm = await fetch('https://fc.yahoo.com', { headers: { 'User-Agent': UA } });
  const cookie = parseSetCookie(warm) || '';
  const crumbRes = await fetch('https://query2.finance.yahoo.com/v1/test/getcrumb', {
    headers: { 'User-Agent': UA, 'Cookie': cookie }
  });
  const crumb = (await crumbRes.text()).trim();
  if (!crumb || crumb.toLowerCase().includes('<html')) {
    throw new Error('Yahoo crumb handshake failed — their session flow may have changed.');
  }
  session = { cookie, crumb, ts: Date.now() };
  return session;
}

// ---------- simple in-memory cache (5 min TTL) to avoid hammering Yahoo ----------
const cache = new Map();
const TTL_MS = 5 * 60 * 1000;
function cacheGet(key){
  const hit = cache.get(key);
  if(!hit) return null;
  if(Date.now() - hit.t > TTL_MS){ cache.delete(key); return null; }
  return hit.v;
}
function cacheSet(key, v){ cache.set(key, { v, t: Date.now() }); }

// ---------- concurrency-limited map ----------
async function mapLimit(items, limit, fn){
  const results = new Array(items.length);
  let idx = 0;
  async function worker(){
    while(idx < items.length){
      const my = idx++;
      try{ results[my] = await fn(items[my]); }
      catch(err){ results[my] = { error: err.message, symbol: items[my] }; }
    }
  }
  await Promise.all(Array.from({length: Math.min(limit, items.length)}, worker));
  return results;
}

// ---------- Yahoo fetchers ----------

async function fetchChart(symbol){
  const cacheKey = 'chart:' + symbol;
  const cached = cacheGet(cacheKey);
  if(cached) return cached;

  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}.NS?range=2y&interval=1d`;
  const res = await fetch(url, { headers: { 'User-Agent': UA } });
  if(!res.ok) throw new Error(`chart fetch failed (${res.status})`);
  const data = await res.json();
  const result = data?.chart?.result?.[0];
  if(!result) throw new Error('no chart data returned');

  const timestamps = result.timestamp || [];
  const closes = result.indicators?.quote?.[0]?.close || [];
  const highs = result.indicators?.quote?.[0]?.high || [];
  const lows = result.indicators?.quote?.[0]?.low || [];

  const series = timestamps
    .map((t, i) => ({ date: new Date(t * 1000), close: closes[i], high: highs[i], low: lows[i] }))
    .filter(p => p.close != null);

  const regularMarketPrice = result.meta?.regularMarketPrice ?? series[series.length - 1]?.close;
  const prevClose = result.meta?.chartPreviousClose ?? series[series.length - 2]?.close;
  const changePct = prevClose ? ((regularMarketPrice - prevClose) / prevClose) * 100 : 0;

  const out = { symbol, series, regularMarketPrice, changePct };
  cacheSet(cacheKey, out);
  return out;
}

async function fetchFundamentals(symbol){
  const cacheKey = 'fund:' + symbol;
  const cached = cacheGet(cacheKey);
  if(cached) return cached;

  const { cookie, crumb } = await getSession();
  const url = `https://query2.finance.yahoo.com/v10/finance/quoteSummary/${symbol}.NS?modules=price,cashflowStatementHistory&crumb=${encodeURIComponent(crumb)}`;
  const res = await fetch(url, { headers: { 'User-Agent': UA, 'Cookie': cookie } });
  if(!res.ok) throw new Error(`fundamentals fetch failed (${res.status})`);
  const data = await res.json();
  const result = data?.quoteSummary?.result?.[0];
  if(!result) throw new Error('no fundamentals data returned');

  const marketCapRaw = result.price?.marketCap?.raw ?? null;
  const marketCapCr = marketCapRaw ? marketCapRaw / 1e7 : null; // paise->crore not needed; INR raw is in rupees, 1 Cr = 1e7

  let cfoCr = null;
  const stmts = result.cashflowStatementHistory?.cashflowStatements;
  if(stmts && stmts.length){
    const cfoRaw = stmts[0]?.totalCashFromOperatingActivities?.raw;
    if(cfoRaw != null) cfoCr = cfoRaw / 1e7;
  }

  const out = { symbol, marketCapCr, cfoCr };
  cacheSet(cacheKey, out);
  return out;
}

// ---------- Cyclic pattern detection (from real 2y daily closes) ----------

function detectCycles(series){
  if(series.length < 40) return null;

  const closes = series.map(p => p.close);
  const window = 10; // trading days on each side to qualify as a local extreme
  const extremes = [];

  for(let i = window; i < closes.length - window; i++){
    const slice = closes.slice(i - window, i + window + 1);
    const v = closes[i];
    if(v === Math.max(...slice)) extremes.push({ i, v, type: 'high' });
    else if(v === Math.min(...slice)) extremes.push({ i, v, type: 'low' });
  }

  // collapse consecutive same-type extremes, keep the more extreme one
  const collapsed = [];
  for(const e of extremes){
    const last = collapsed[collapsed.length - 1];
    if(last && last.type === e.type){
      if((e.type === 'high' && e.v > last.v) || (e.type === 'low' && e.v < last.v)){
        collapsed[collapsed.length - 1] = e;
      }
    } else {
      collapsed.push(e);
    }
  }

  // filter out swings smaller than 8%
  const swings = [];
  for(let i = 1; i < collapsed.length; i++){
    const a = collapsed[i - 1], b = collapsed[i];
    const swingPct = Math.abs(b.v - a.v) / a.v * 100;
    if(swingPct >= 8) swings.push({ from: a, to: b, swingPct });
  }

  if(swings.length < 2) return null; // need at least 2 real swings to call it cyclic

  const avgSwing = swings.reduce((s, x) => s + x.swingPct, 0) / swings.length;

  // gap in calendar days between same-type extremes (low-to-low, high-to-high)
  const gaps = [];
  for(let t of ['high', 'low']){
    const seq = collapsed.filter(e => e.type === t);
    for(let i = 1; i < seq.length; i++){
      const days = (series[seq[i].i].date - series[seq[i - 1].i].date) / 86400000;
      gaps.push(days);
    }
  }
  if(gaps.length === 0) return null;

  const avgGap = gaps.reduce((s, x) => s + x, 0) / gaps.length;
  const variance = gaps.reduce((s, x) => s + Math.pow(x - avgGap, 2), 0) / gaps.length;
  const stdDev = Math.sqrt(variance);
  const irregular = stdDev > avgGap * 0.6;

  let cycleType;
  if(irregular) cycleType = 'Irregular';
  else if(avgGap <= 15) cycleType = 'Daily';
  else if(avgGap <= 45) cycleType = 'Monthly';
  else if(avgGap <= 110) cycleType = 'Quarterly';
  else if(avgGap <= 220) cycleType = 'Half-Yearly';
  else cycleType = 'Yearly';

  // downsample to ~14 points for a sparkline
  const step = Math.max(1, Math.floor(closes.length / 14));
  const spark = closes.filter((_, i) => i % step === 0).slice(-14);

  // The price bands the stock has actually been oscillating between —
  // this is what lets the tab show "rises to ~₹420, falls to ~₹370" style
  // detail instead of just a cycle label.
  const highVals = collapsed.filter(e => e.type === 'high').map(e => e.v);
  const lowVals = collapsed.filter(e => e.type === 'low').map(e => e.v);
  const bandUpper = Math.round(highVals.reduce((s, x) => s + x, 0) / highVals.length);
  const bandLower = Math.round(lowVals.reduce((s, x) => s + x, 0) / lowVals.length);

  return {
    cycleType,
    avgSwingPct: Math.round(avgSwing * 10) / 10,
    cyclesDetected: swings.length,
    bandUpper,
    bandLower,
    spark
  };
}

// ---------- AI research (FUT tab) ----------
// This is what makes the FUT tab "reason" about a stock instead of just
// running a price filter: it calls Claude with the web_search tool turned
// on, so the model does real, live web searches per stock — recent
// quarterly balance sheet trends, shareholding pattern changes, order
// book / work order news — and writes them up. It never issues a buy
// signal or a price target; the system prompt below explicitly forbids
// that. Treat its output as a research starting point, not a verdict.

const RESEARCH_SYSTEM_PROMPT = `You are a cautious equity research assistant helping screen small/micro-cap Indian (NSE-listed) stocks for a research tool. You have live web search — use it.

For the stock you're given, search for and report on:
1. Recent quarterly balance sheet trend — revenue growth or decline, debt levels, profitability trend. Name the quarter/date of whatever you find.
2. Shareholding pattern — recent trend in promoter holding (rising, falling, or steady), any promoter share pledging, and FII/DII holding trend if available.
3. Order book / work orders — recent new contract wins or order book announcements, if the company's sector makes this relevant (e.g. infrastructure, EPC, defence, engineering, capital goods). If not relevant to this company's business, say so.

Write a balanced research note, 150-220 words, in plain prose. Cite approximate dates for anything you report ("as of the June 2026 quarter", "as of the latest filing you can find"). Explicitly call out red flags if you find them: promoter pledging, declining revenue, rising debt, a stale or shrinking order book, or a lack of recent public information.

Hard rules:
- Never write "buy", "target price", "will multibag", or any claim that the stock will succeed. You are producing research context, not a recommendation.
- If you cannot find reliable recent information for a section, say so plainly rather than guessing or inferring from the company name/sector alone.
- End your note with exactly one line, starting with "RISK LEVEL:" followed by Low, Medium, or High, based on what you actually found (thin/no data, pledging, or a stretched balance sheet should push this toward High).`;

async function researchStock(ticker) {
  if (!ANTHROPIC_API_KEY) {
    return { available: false, reason: 'ANTHROPIC_API_KEY not set in .env' };
  }
  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-5',
        max_tokens: 700,
        system: RESEARCH_SYSTEM_PROMPT,
        messages: [{
          role: 'user',
          content: `Research ${ticker}, listed on the NSE (India). Look into its recent balance sheet trend, shareholding pattern, and order book / work orders as described in your instructions.`
        }],
        tools: [{ type: 'web_search_20250305', name: 'web_search' }]
      })
    });
    const data = await res.json();
    if (data.error) return { available: false, reason: data.error.message };

    const text = (data.content || [])
      .filter(b => b.type === 'text')
      .map(b => b.text)
      .join('\n')
      .trim();

    if (!text) return { available: false, reason: 'Model returned no text content' };

    const riskMatch = text.match(/RISK LEVEL:\s*(Low|Medium|High)/i);
    return {
      available: true,
      note: text.replace(/RISK LEVEL:\s*(Low|Medium|High)/i, '').trim(),
      riskLevel: riskMatch ? riskMatch[1] : null
    };
  } catch (err) {
    console.warn(`AI research failed for ${ticker}:`, err.message);
    return { available: false, reason: err.message };
  }
}

// Research calls are slow and cost real API usage (web search + generation
// per stock), so they're cached far longer than price data.
const researchCache = new Map();
const RESEARCH_TTL_MS = 4 * 60 * 60 * 1000; // 4 hours

async function getResearchCached(ticker) {
  const hit = researchCache.get(ticker);
  if (hit && Date.now() - hit.t < RESEARCH_TTL_MS) return hit.v;
  const v = await researchStock(ticker);
  if (v.available) researchCache.set(ticker, { v, t: Date.now() }); // don't cache failures — retry next time
  return v;
}

// ---------- Watchlists ----------

const WATCHLIST_CYCLIC = ['TATAPOWER','TATASTEEL','JSWSTEEL','HINDALCO','VEDL','NMDC','BALRAMCHIN','ULTRACEMCO','ASHOKLEY','COROMANDEL','BHARATFORG','TATAMOTORS','SAIL','NATIONALUM','CHAMBLFERT','GNFC'];
const WATCHLIST_CFO = ['COALINDIA','NMDC','GAIL','ONGC','NTPC','POWERGRID','HINDZINC','RECLTD','OIL','PFC','IOC','BPCL','SAIL','NATIONALUM'];
const WATCHLIST_52W = ['PAYTM','INDUSINDBK','ZEEL','PVRINOX','IDFCFIRSTB','BANDHANBNK','DELTACORP','PEL','AUBANK','SUNTV','MOTHERSON','GMRINFRA','IEX','LICHSGFIN'];
const WATCHLIST_FUT = ['SUZLON','YESBANK','IDEA','RTNPOWER','JPPOWER','GTLINFRA','RPOWER','SOUTHBANK','IFCI','IOB','UCOBANK','CENTRALBK','ALOKINDS','TRIDENT','PNB'];

// ---------- Routes ----------

app.get('/api/cyclic', async (req, res) => {
  const results = await mapLimit(WATCHLIST_CYCLIC, 4, async (sym) => {
    const chart = await fetchChart(sym);
    const cycle = detectCycles(chart.series);
    if(!cycle) return null;
    return {
      ticker: sym,
      cmp: chart.regularMarketPrice,
      chg: chart.changePct,
      ...cycle
    };
  });
  const ok = results.filter(r => r && !r.error);
  const errors = results.filter(r => r && r.error).map(r => r.symbol);
  res.json({ asOf: new Date().toISOString(), source: 'Yahoo Finance (unofficial, ~15min delayed)', results: ok, errors });
});

app.get('/api/cfo', async (req, res) => {
  const results = await mapLimit(WATCHLIST_CFO, 4, async (sym) => {
    const [chart, fund] = await Promise.all([fetchChart(sym), fetchFundamentals(sym)]);
    if(fund.marketCapCr == null || fund.cfoCr == null) return { unavailable: true, ticker: sym };
    const ratioPct = (fund.cfoCr / fund.marketCapCr) * 100;
    if(ratioPct < 5) return null;
    return {
      ticker: sym,
      cmp: chart.regularMarketPrice,
      chg: chart.changePct,
      cfoCr: Math.round(fund.cfoCr),
      mcapCr: Math.round(fund.marketCapCr),
      ratioPct: Math.round(ratioPct * 10) / 10,
      ratioX: Math.round((fund.marketCapCr / fund.cfoCr) * 10) / 10
    };
  });
  const ok = results.filter(r => r && !r.error && !r.unavailable);
  const unavailable = results.filter(r => r && r.unavailable).map(r => r.ticker);
  const errors = results.filter(r => r && r.error).map(r => r.symbol);
  res.json({ asOf: new Date().toISOString(), source: 'Yahoo Finance (unofficial, fundamentals coverage varies)', results: ok, unavailable, errors });
});

app.get('/api/52wlow', async (req, res) => {
  const results = await mapLimit(WATCHLIST_52W, 4, async (sym) => {
    const [chart, fund] = await Promise.all([fetchChart(sym), fetchFundamentals(sym)]);
    if(fund.marketCapCr == null || fund.marketCapCr <= 2000) return null;
    const last252 = chart.series.slice(-252);
    const low52 = Math.min(...last252.map(p => p.low ?? p.close));
    const high52 = Math.max(...last252.map(p => p.high ?? p.close));
    const distFromLow = ((chart.regularMarketPrice - low52) / low52) * 100;
    return {
      ticker: sym,
      cmp: chart.regularMarketPrice,
      low52, high52,
      mcapCr: Math.round(fund.marketCapCr),
      distFromLow: Math.round(distFromLow * 10) / 10
    };
  });
  const ok = results.filter(r => r && !r.error).sort((a,b) => a.distFromLow - b.distFromLow);
  const errors = results.filter(r => r && r.error).map(r => r.symbol);
  res.json({ asOf: new Date().toISOString(), source: 'Yahoo Finance (unofficial, ~15min delayed)', results: ok, errors });
});

app.get('/api/fut', async (req, res) => {
  const priceCeiling = parseFloat(req.query.maxPrice) || 100;
  const mcapFloor = parseFloat(req.query.minMcap) || 500;
  const RESEARCH_LIMIT = 5; // cap how many stocks get an AI research call per scan

  const technicalResults = await mapLimit(WATCHLIST_FUT, 4, async (sym) => {
    const [chart, fund] = await Promise.all([fetchChart(sym), fetchFundamentals(sym)]);
    if(chart.regularMarketPrice > priceCeiling) return null;
    if(fund.marketCapCr == null || fund.marketCapCr < mcapFloor) return null;

    const closes = chart.series.map(p => p.close);
    const last252 = closes.slice(-252);
    const low1y = Math.min(...last252);
    const upFromLow = ((chart.regularMarketPrice - low1y) / low1y) * 100;

    const last20 = closes.slice(-20);
    const last60 = closes.slice(-60);
    const avg20 = last20.reduce((s,x)=>s+x,0) / last20.length;
    const avg60 = last60.reduce((s,x)=>s+x,0) / last60.length;
    const inUptrend = avg20 > avg60;

    // Basic quality gate: require genuinely positive operating cash flow,
    // not just price momentum. Momentum-only screens are exactly the
    // pattern a pump-and-dump also produces, so this alone doesn't make
    // the screen safe — it's one guardrail, not a green light.
    const cfoPositive = fund.cfoCr != null && fund.cfoCr > 0;

    const criteriaMet = [];
    if(upFromLow >= 15) criteriaMet.push(`+${Math.round(upFromLow)}% off 1Y low`);
    if(inUptrend) criteriaMet.push('20D avg > 60D avg (uptrend)');
    if(fund.marketCapCr >= mcapFloor) criteriaMet.push(`MCap ₹${Math.round(fund.marketCapCr)} Cr (liquidity floor met)`);
    if(cfoPositive) criteriaMet.push(`Positive operating cash flow (₹${Math.round(fund.cfoCr)} Cr)`);

    // require momentum + uptrend + a real cash-flow gate to qualify
    if(upFromLow < 15 || !inUptrend || !cfoPositive) return null;

    return {
      ticker: sym,
      cmp: chart.regularMarketPrice,
      chg: chart.changePct,
      mcapCr: Math.round(fund.marketCapCr),
      upFromLow: Math.round(upFromLow),
      criteriaMet
    };
  });

  let ok = technicalResults.filter(r => r && !r.error).sort((a,b) => b.upFromLow - a.upFromLow);
  const errors = technicalResults.filter(r => r && r.error).map(r => r.symbol);

  // AI research pass — only on the strongest technical survivors, and only
  // if a key is configured. This is what actually looks at balance sheet
  // trend, shareholding pattern, and order book instead of price alone.
  const toResearch = ok.slice(0, RESEARCH_LIMIT);
  const researched = await mapLimit(toResearch, 2, async (stock) => {
    const research = await getResearchCached(stock.ticker);
    return { ...stock, research };
  });
  ok = researched.concat(ok.slice(RESEARCH_LIMIT).map(s => ({ ...s, research: { available: false, reason: 'Not in top ' + RESEARCH_LIMIT + ' by momentum this scan — AI research is capped per run to control cost/latency.' } })));

  res.json({
    asOf: new Date().toISOString(),
    source: ANTHROPIC_API_KEY
      ? 'Yahoo Finance (price/momentum) + Claude with live web search (balance sheet, shareholding, order book)'
      : 'Yahoo Finance (price/momentum) only — set ANTHROPIC_API_KEY in .env to enable AI research',
    results: ok,
    errors,
    criteria: { priceCeiling, mcapFloor, researchLimit: RESEARCH_LIMIT }
  });
});

app.listen(PORT, () => {
  console.log(`StockRadar live backend running at http://localhost:${PORT}`);
});

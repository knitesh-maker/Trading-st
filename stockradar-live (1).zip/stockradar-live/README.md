# StockRadar — Live build

This version fetches real market data on every load/refresh — no
hardcoded numbers. Two data sources, each doing the job it's actually
good at:

- **Yahoo Finance's unofficial, free, no-key feed** — real price
  history, used for CYCLIC, CFO, 52W LOW, and the price/momentum part
  of FUT. This needs no signup at all.
- **The Anthropic API, with Claude's live web-search tool** — used
  only for the FUT tab's "AI research" (balance sheet trend,
  shareholding pattern, order book). This is the one piece that needs
  your own API key, because that kind of qualitative research isn't
  in any free price feed.

## Folder contents

```
stockradar-live/
├── server.js       backend — fetches Yahoo data, runs AI research, computes screens
├── package.json
├── .env.example    copy to .env and add your Anthropic key
└── public/
    └── index.html  the app UI (4 tabs)
```

## Setup

1. Node.js 18+ required (`node -v` to check — needs built-in `fetch`).
2. In this folder, run:
   ```
   npm install
   ```
3. **Optional but recommended:** copy `.env.example` to `.env` and add
   your Anthropic API key (get one at console.anthropic.com). Without
   this, CYCLIC/CFO/52W LOW work exactly the same, and FUT still shows
   its price/momentum shortlist — it just skips the AI research part
   and says so on-screen rather than failing silently.
4. Start it:
   ```
   npm start
   ```
5. Open `http://localhost:3002`.

## How each tab actually works

**CYCLIC** — fetches 2 years of daily closing prices per stock, finds
local highs/lows with at least an 8% swing between them, and measures
the average number of days between repeats to classify the rhythm
(Daily / Monthly / Quarterly / Half-Yearly / Yearly / Irregular). It
also reports the actual price bands detected — e.g. "₹370–₹420" — by
averaging the real highs and real lows it found, so a stock showing
up here comes with the specific levels it's been swinging between,
not just a label. This is a real computation over real price history,
not a lookup — so if a stock (like Tata Power) genuinely does swing
between roughly the same two price bands every ~6 months, it will
show up here on its own, without needing to be hardcoded.

**CFO** — fetches market cap and cash-flow-from-operations for each
stock via Yahoo's fundamentals module, keeps only stocks where
CFO ÷ Market Cap ≥ 5% (a 1:20 ratio or stronger).

**52W LOW** — computes the actual 52-week high/low from the fetched
price history (not from a possibly-stale meta field), filters to
market cap > ₹2,000 Cr, and sorts by proximity to the low.

**FUT** — runs in two passes:
1. *Technical shortlist (free, fast):* stocks priced ≤ ₹100, at least
   15% above their 1-year low, in a rising short-term trend (20-day
   average price above the 60-day average), with genuinely positive
   operating cash flow. This alone is still just a momentum screen —
   a pure price filter produces exactly the same signature as a
   pump-and-dump in progress, which is why the cash-flow gate exists.
2. *AI research (paid, slower, only if `ANTHROPIC_API_KEY` is set):*
   the top 5 stocks from the shortlist get a live research pass —
   Claude, with its web search tool turned on, actually looks up each
   company's recent balance sheet trend, shareholding pattern
   (promoter holding, pledging), and order book / work order news,
   and writes a short balanced note ending in an explicit RISK LEVEL.
   The system prompt hard-forbids the words "buy", "target price", or
   any claim the stock will succeed — this is a research summary, not
   a recommendation. Results are cached 4 hours per stock since each
   call costs real API usage.

None of this is full fundamental vetting (no audited debt schedules,
no earnings-quality analysis), and it is never a prediction of which
stock becomes a multibagger — treat both passes as a shortlist to
research further yourself, not a conclusion.

## Honest limitations — read before you pitch this

1. **Yahoo's endpoint is unofficial and undocumented.** It can change,
   rate-limit, or block requests without notice. It works well enough
   for a demo and even a small pilot, but it is not something to build
   a funded product's core data layer on. For production, budget for
   a licensed feed: Zerodha Kite Connect, Upstox API, or a data vendor
   like Trendlyne/Tijori Finance.
   The fundamentals endpoint (`fetchFundamentals`) now performs a
   cookie + "crumb" handshake (`getSession()` in `server.js`) because
   Yahoo increasingly requires this or it returns an HTML error page
   instead of JSON. This handshake is exactly the kind of thing Yahoo
   changes without notice — if CFO/52W/FUT tabs start failing, this is
   the first place to check, and server logs will show the error.
2. **Data is delayed, not real-time.** NSE quotes via this route are
   typically ~15 minutes behind the actual market. True real-time
   requires a licensed/broker feed.
3. **Fundamentals coverage is inconsistent.** Market cap and CFO come
   from a different, more fragile Yahoo module than price data. If a
   stock shows as "unavailable" or is missing from the CFO/52W-LOW
   tabs, that's the app being honest about a failed fetch — it is not
   silently substituting a fake number.
4. **The watchlists are fixed, not the full market.** Each tab scans
   a hand-picked list of 14–16 tickers (see `WATCHLIST_*` in
   `server.js`), not all ~2,000 NSE-listed stocks. Scanning the whole
   market would need a bulk data source, which free unofficial
   endpoints don't reliably support without getting rate-limited.
   Expand the watchlists as needed, but expect more failures as you
   scale up on a free source.
5. **Nothing here is investment advice**, especially the FUT tab —
   penny stocks are the segment most prone to manipulation and
   illiquidity. Read the AI research note and risk level, don't just
   glance at the badges.
6. **AI research costs real money per call.** Each researched stock
   triggers a Claude API call with web search enabled — check current
   pricing at anthropic.com/pricing before running this repeatedly
   against a large watchlist. The 5-stock cap and 4-hour cache in
   `server.js` (`RESEARCH_LIMIT`, `RESEARCH_TTL_MS`) exist to control
   this; raise them deliberately, not by accident.
7. **AI research quality depends on what's publicly searchable.** For
   thinly-covered micro-caps, Claude may find little or nothing for
   some sections — the system prompt requires it to say so rather
   than guess, so "could not find recent data" is an honest result,
   not a bug.

## Moving to a licensed data source later

Swap `fetchChart()` and `fetchFundamentals()` in `server.js` for calls
to your chosen provider's SDK — the rest of the app (cycle detection,
screening logic, UI) doesn't need to change, since it all operates on
the same `{ series, regularMarketPrice, marketCapCr, cfoCr }` shape.
